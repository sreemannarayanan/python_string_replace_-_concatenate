import string
string1 = raw_input("Enter the first string : ")
string2 = raw_input("Enter the second string : ")
print 'First string and second string are concatenated and result is :' + string1+string2 
