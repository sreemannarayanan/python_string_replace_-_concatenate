import string
old_string = raw_input("Enter the string whose first character has to be changed to 1 : ")
print 'String before any replacement is : '+ old_string
new_string = string.replace(old_string,old_string[0],'1')
print 'String after replacement is : ' + new_string

